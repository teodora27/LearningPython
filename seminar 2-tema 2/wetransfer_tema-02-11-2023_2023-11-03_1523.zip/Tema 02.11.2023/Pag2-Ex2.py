import re


def sol(text):
    # Separam cuvintele din text dupa orice caracter care nu este litera
    words = [word.lower() for word in re.split(r"[^a-zA-Z]", text) if word != '']

    # Parcurgem cuvintele si adaugam la resultat fiecare cuvant distinct folosind un dictionar
    found, res = {}, 0
    for word in words:
        if word not in found:
            res += 1
            found[word] = True

    return res


def main():
    text = input()
    print(sol(text))


main()
