def sol_encrypt(text):
    encrypted_text = ''

    # Parcurgem textul caracter cu caracter si mutam 3 pozitii mai la stanga in ascii,
    # apoi adaugam caracterul in rezultat
    for char in text:
        if char.isalpha():
            mod_val = ord('a' if char.islower() else 'A')
            encrypted_text += chr((ord(char) - mod_val + 23) % 26 + mod_val)
        else:
            encrypted_text += char

    return encrypted_text


def sol_decrypt(text):
    decrypted_text = ''

    # Parcurgem textul caracter cu caracter si mutam 3 pozitii mai la dreapta in ascii,
    # apoi adaugam caracterul in rezultat
    for char in text:
        if char.isalpha():
            mod_val = ord('a' if char.islower() else 'A')
            decrypted_text += chr((ord(char) - mod_val - 23) % 26 + mod_val)
        else:
            decrypted_text += char

    return decrypted_text


def main():
    # Folosim Cifrul lui Cezar pentru a cripta sirul, rotind fiecare caracter cu 3 pozitii mai la stanga in sirul ascii
    text = input()
    encrypted_text = sol_encrypt(text)
    decrypted_text = sol_decrypt(encrypted_text)

    print(encrypted_text)
    print(decrypted_text)


main()
