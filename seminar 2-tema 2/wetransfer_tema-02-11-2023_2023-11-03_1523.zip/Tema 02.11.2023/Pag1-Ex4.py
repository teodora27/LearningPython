def sol(numbers):
    # Luam toate cifrele din toate numerele si le concatenam
    all_digits = []
    for number in numbers:
        for char in number:
            all_digits.append(char)

    # Sortam cifrele crescator
    all_digits.sort()

    for i in range(len(all_digits)):
        if all_digits[i] != '0':
            # Facem swap cu prima cifra diferita de 0 si prima pozitie din sir pentru a forma un numar valid
            # si afisam minimul
            all_digits[i], all_digits[0] = all_digits[0], all_digits[i]
            print(f"Minim: {''.join(all_digits)}\n")

            # Facem swap inapoi, inversam sirul si afisam maximul
            all_digits[i], all_digits[0] = all_digits[0], all_digits[i]
            all_digits.reverse()
            print(f"Maxim: {''.join(all_digits)}\n")
            return


def main():
    file = open("numere.txt", "r")
    lines, numbers = file.readlines(), []

    for line in lines:
        for val in line.split():
            numbers.append(val)

    sol(numbers)


main()
