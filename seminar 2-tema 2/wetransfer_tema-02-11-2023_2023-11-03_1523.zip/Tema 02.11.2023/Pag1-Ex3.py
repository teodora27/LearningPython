import re


def sol(text):
    # Separam cuvintele dupa orice caracter care nu este litera
    words = [word.lower() for word in re.split(r"[^a-zA-Z]", text) if word != '']

    # Punem cuvintele intr-un dictionary cu valoarea fiind lungimea lor pentru a scapa de duplicate
    freq = {}
    for word in words:
        freq[word] = len(word)

    # Facem o lista sortata dupa dictionary
    res = sorted(freq.items(), key=lambda item: item[1], reverse=True)

    file = open('grupe_cuvinte.txt', 'w')

    # Afisam cuvintele corespunzatoare fiecarei lungimi
    curr_len = res[0][1]
    file.write(f"Lungime {curr_len}: {res[0][0]}")

    for elem in res[1:]:
        if elem[1] == curr_len:
            file.write(', ' + elem[0])
        else:
            curr_len = elem[1]
            file.write(f"\nLungime {curr_len}: {elem[0]}")


def main():
    file = open('exemplu.txt', 'r')
    text = file.read()
    sol(text)


main()
