def sol(words, find_len):
    found = {}
    # Pentru fiecare cuvant verificam daca are acelasi nr de caractere si daca se afla sau nu in dictionar
    for word in words:
        if len(word) == find_len and word not in found:
            print(word)
            found[word] = True

    return


def main():
    word = input()
    text = input().split()

    sol(text, len(word))


main()
