def sol(str1, str2):
    # Initializam vectorul de frecventa si facem sirurile lower-case
    freq = [0] * 30
    str1, str2 = str1.lower(), str2.lower()

    # Adunam 1 pentru fiecare aparitie din primul sir si scadem 1 pentru fiecare aparitie din al doilea sir
    for char in str1:
        freq[int(ord(char) - 97)] += 1

    for char in str2:
        freq[int(ord(char) - 97)] -= 1

    # Daca vectorul de frecventa este gol la final inseamna ca cele 2 siruri sunt anagrame
    for val in freq:
        if val != 0:
            return False

    return True


def main():
    str1 = input()
    str2 = input()
    print(sol(str1, str2))


main()
