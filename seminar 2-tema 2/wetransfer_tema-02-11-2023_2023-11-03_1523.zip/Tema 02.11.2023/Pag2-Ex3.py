import re


def sol(text):
    # Facem o lista cu toate caracterele de fiecare tip
    lowercase_letters = re.findall(r"[a-z]", text)
    uppercase_letters = re.findall(r"[A-Z]", text)
    punctuation_symbols = re.findall(r",|!|\.|'|\?", string=text)

    # Afisam lungimea fiecarei liste
    print(f"Nr litere mici: {len(lowercase_letters)}")
    print(f"Nr litere mari: {len(uppercase_letters)}")
    print(f"Nr semne de punctuatie: {len(punctuation_symbols)}")


def main():
    text = input()
    sol(text)


main()
